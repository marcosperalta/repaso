#ifndef _TYPE_ELEM_H
#define _TYPE_ELEM_H

#include "graph.h"

/* Type for elements */
typedef vertex_t type_elem;

#endif
